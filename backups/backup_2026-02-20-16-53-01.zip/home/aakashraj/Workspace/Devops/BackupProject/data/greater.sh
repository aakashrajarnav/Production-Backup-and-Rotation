#!/bin/sh

a=10
b=20

if [ $a -gt $b ]; then
        echo "$a is bigger"
else
        echo "$b is bigger"
fi
