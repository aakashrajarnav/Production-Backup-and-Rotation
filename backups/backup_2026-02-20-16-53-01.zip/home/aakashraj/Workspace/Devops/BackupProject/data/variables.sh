#!/bin/bash


read -p "Enter your name: " Name
echo "My Name is $Name"
