#!/bin/bash

mkdir fun 2>/dev/null
echo "do production work"
