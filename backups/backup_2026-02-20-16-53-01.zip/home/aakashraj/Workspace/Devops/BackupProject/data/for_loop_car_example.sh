#!/bin/bash


for car in audi bmw tata maruti porche
do
	echo $car
done
